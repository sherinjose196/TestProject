# Laravel Passport - Create REST API with authentication
> How to install
 - Clone the repository
 - Set up database credentials in .env file
 - Run `composer update`
 - Run `php artisan migrate` to migrate the database
 - Run `php artisan passport:install`


Read the tutorial at [Laravel Passport - Create REST API with authentication](https://tutsforweb.com/laravel-passport-create-rest-api-with-authentication)

Learn more about Laravel at [https://tutsforweb.com](https://tutsforweb.com)
